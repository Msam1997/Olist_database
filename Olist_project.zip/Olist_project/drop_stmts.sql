drop table customer_dataset;
drop table order_items;
drop table product_dataset;
drop table seller_dataset;
drop table payment;
drop table order_reviews;
drop table order_dataset;

